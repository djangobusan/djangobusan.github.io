from django.shortcuts import render
from .models import Todo


def todo_list(request):
    todos = Todo.objects.all()
    return render(request, 'todo/todo_list.html', {
        'todos': todos
    })


def todo_new(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        text = request.POST.get('text')

        if title and text:
            todo = Todo()
            todo.title = title
            todo.text = text
            todo.save()

        return render(request, 'todo/todo_new.html')
    else:
        return render(request, 'todo/todo_new.html')
