from django.apps import AppConfig


class CoffeeshopConfig(AppConfig):
    name = 'coffeeshop'
