from django.shortcuts import render
from .models import Menu


def menu_list(request):
    menus = Menu.objects.all()
    return render(request, 'shop/menu_list.html', {
        'menus': menus
    })
